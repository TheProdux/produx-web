<?php

$to 		= 'oviyas@hotmail.com,support@theprodux.com,produxdesk@gmail.com,raj@theprodux.com';
$subject 	= 'Quote request';
$from 		= $_POST['f_6'];
$req_data	= $_POST['hidRes'];
 
// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
// Create email headers
$headers .= 'From: '.$from."\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();
 
// Compose a simple HTML email message
$message = '<html><body>';
$message .= '<h1 style="color:#f40;">Hi Admin!</h1>';
$message .= '<h2 style="color:#8E44AD;">Use Promocode "RBTECH-10" to avail 10% OFF from this estimation </h2>';
$message .= '<p style="color:#080;font-size:18px;">'.$req_data.'</p>';
$message .= '</body></html>';
 
// Sending email
if(mail($to, $subject, $message, $headers)){
    echo "<script>alert('Thanks for contacting us!!!.');</script>";
} else{
    echo 'Unable to send email. Please try again.';
}
echo "<script>location.href='index.html';</script>";

?>
<?php include_once("analyticstracking.php") ?>


